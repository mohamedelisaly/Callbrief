package com.example.callbrief

// build.gradle (app) dependencies:
//   implementation("com.squareup.okhttp3:okhttp:4.12.0")
//   implementation("androidx.core:core-ktx:1.13.1")
//   implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
// minSdk 26, targetSdk 34

import android.annotation.SuppressLint
import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.*
import android.graphics.PixelFormat
import android.net.Uri
import android.os.*
import android.provider.ContactsContract
import android.provider.ContactsContract.CommonDataKinds.Phone
import android.provider.ContactsContract.CommonDataKinds.StructuredName
import android.provider.Settings
import android.provider.Telephony
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.telecom.TelecomManager
import android.telephony.SubscriptionManager
import android.telephony.TelephonyManager
import android.util.Log
import android.view.Gravity
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.view.WindowManager
import android.widget.*
import androidx.core.widget.doAfterTextChanged
import kotlinx.coroutines.*
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/* ───────────── تخزين بسيط ───────────── */
object Store {
    private fun sp(c: Context) = c.getSharedPreferences("cb", 0)
    fun k(n: String) = n.filter { it.isDigit() }.takeLast(9).ifEmpty { "unknown" }
    fun brief(c: Context, n: String): String? = sp(c).getString("b" + k(n), null)
    fun saveBrief(c: Context, n: String, t: String) = sp(c).edit().putString("b" + k(n), t).apply()
    fun cfg(c: Context, key: String) = sp(c).getString(key, "") ?: ""
    fun setCfg(c: Context, key: String, v: String) = sp(c).edit().putString(key, v).apply()
}

/* ───────────── جهات الاتصال + الرسائل ───────────── */
object Contacts {
    @SuppressLint("MissingPermission")
    fun name(c: Context, num: String): String? =
        if (num.isBlank()) null else c.contentResolver.query(
            Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(num)),
            arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME), null, null, null
        )?.use { if (it.moveToFirst()) it.getString(0) else null }

    fun numberOf(c: Context, name: String): String? =
        c.contentResolver.query(
            Phone.CONTENT_URI, arrayOf(Phone.NUMBER),
            "${Phone.DISPLAY_NAME} LIKE ?", arrayOf("%$name%"), null
        )?.use { if (it.moveToFirst()) it.getString(0) else null }

    fun save(c: Context, name: String, num: String) {
        val ops = arrayListOf(
            ContentProviderOperation.newInsert(ContactsContract.RawContacts.CONTENT_URI)
                .withValue(ContactsContract.RawContacts.ACCOUNT_TYPE, null)
                .withValue(ContactsContract.RawContacts.ACCOUNT_NAME, null).build(),
            ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI)
                .withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, 0)
                .withValue(ContactsContract.Data.MIMETYPE, StructuredName.CONTENT_ITEM_TYPE)
                .withValue(StructuredName.DISPLAY_NAME, name).build(),
            ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI)
                .withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, 0)
                .withValue(ContactsContract.Data.MIMETYPE, Phone.CONTENT_ITEM_TYPE)
                .withValue(Phone.NUMBER, num).withValue(Phone.TYPE, Phone.TYPE_MOBILE).build()
        )
        c.contentResolver.applyBatch(ContactsContract.AUTHORITY, ops)
    }
}

object Msgs {
    fun last(c: Context, num: String): String =
        c.contentResolver.query(
            Telephony.Sms.CONTENT_URI, arrayOf(Telephony.Sms.BODY, Telephony.Sms.TYPE),
            "${Telephony.Sms.ADDRESS} LIKE ?", arrayOf("%${Store.k(num)}%"), "date DESC"
        )?.use {
            buildList {
                while (it.moveToNext() && size < 5)
                    add((if (it.getInt(1) == 1) "هو: " else "أنا: ") + it.getString(0))
            }.reversed().joinToString("\n")
        } ?: ""
}

/* ───────────── آخر رسالة واتساب (من إشعارات النظام بإذنك) ───────────── */
object Wa {
    fun save(c: Context, title: String, text: String, time: Long) {
        c.getSharedPreferences("cb_wa", 0).edit().putString("w_${title.trim()}", "$time|$text").apply()
    }

    fun lastFor(c: Context, num: String): String {
        val sp = c.getSharedPreferences("cb_wa", 0)
        val name = Contacts.name(c, num)
        val raw = (name?.let { sp.getString("w_$it", null) }
            ?: sp.getString("w_$num", null)
            ?: sp.getString("w_${num.takeLast(9)}", null)) ?: return ""
        val time = raw.substringBefore("|").toLongOrNull() ?: 0L
        val date = SimpleDateFormat("dd/MM HH:mm", Locale.getDefault()).format(Date(time))
        return "($date) ${raw.substringAfter("|")}"
    }
}

class WaListener : android.service.notification.NotificationListenerService() {
    override fun onNotificationPosted(sbn: android.service.notification.StatusBarNotification) {
        if (sbn.packageName != "com.whatsapp" && sbn.packageName != "com.whatsapp.w4b") return
        val ex = sbn.notification.extras
        val title = ex.getCharSequence(android.app.Notification.EXTRA_TITLE)?.toString() ?: return
        val text = ex.getCharSequence(android.app.Notification.EXTRA_TEXT)?.toString() ?: return
        Wa.save(applicationContext, title, text, sbn.postTime)
    }
}

/* ───────────── التلخيص (Claude) ───────────── */
object Brain {
    private val http = OkHttpClient()

    fun ask(c: Context, system: String, user: String): String {
        val body = JSONObject().put("model", "claude-haiku-5-5").put("max_tokens", 300)
            .put("system", system)
            .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", user)))
            .toString()
        val req = Request.Builder().url("https://api.anthropic.com/v1/messages")
            .header("x-api-key", Store.cfg(c, "key")).header("anthropic-version", "2023-06-01")
            .post(body.toRequestBody("application/json".toMediaType())).build()
        http.newCall(req).execute().use { resp ->
            val raw = resp.body?.string() ?: ""
            if (!resp.isSuccessful) throw RuntimeException("HTTP ${resp.code}: $raw")
            return JSONObject(raw).getJSONArray("content").getJSONObject(0).getString("text")
        }
    }
}

private const val SYS = """رد بـ JSON فقط بدون أي شرح أو علامات: {"brief":"ملخص بالمصري في سطرين لآخر تفاعل بس، مبني على ملاحظة المستخدم بعد المكالمة (والرسائل لو بتوضح)، من غير أي حاجة قديمة","name":"اسم الشخص وصفته زي: أحمد - فني تكييف، أو محمد - مدير مشتريات، بالظبط زي ما المستخدم قالهم في ملاحظته. لو قال الاسم بس اكتب الاسم، ولو مقالش حاجة سيبها فاضية"}"""

/* ───────────── معالجة الملاحظة + ملف خاص بكل شخص ───────────── */
object Notes {
    fun file(c: Context, num: String): File =
        File(File(c.filesDir, "people").apply { mkdirs() }, Store.k(num) + ".txt")

    fun process(c: Context, num: String, note: String) {
        if (note.isBlank()) return
        var brief = note.take(200) // لو الإنترنت أو المفتاح فيهم مشكلة، نحفظ الملاحظة نفسها
        var name = ""
        try {
            val raw = Brain.ask(
                c, SYS, "ملاحظتي بعد المكالمة:\n$note\nآخر SMS:\n${Msgs.last(c, num)}\nآخر واتساب:\n${Wa.lastFor(c, num)}"
            )
            val s = raw.indexOf('{'); val e = raw.lastIndexOf('}')
            if (s != -1 && e > s) {
                val r = JSONObject(raw.substring(s, e + 1))
                brief = r.optString("brief", brief); name = r.optString("name", "")
            }
        } catch (e: Exception) { Log.e("CallBrief", "summary failed", e) }

        Store.saveBrief(c, num, brief) // بيستبدل القديم
        val date = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date())
        file(c, num).appendText("[$date] $brief\nالملاحظة الأصلية: $note\n\n")

        if (Contacts.name(c, num) == null)
            Pop.show(c, "رقم جديد: $num", brief, name) { n ->
                Thread { Contacts.save(c, n, num) }.start()
            }
    }
}

/* ───────────── البوب أب ───────────── */
object Pop {
    fun show(c: Context, title: String, body: String, name: String? = null, onSave: ((String) -> Unit)? = null) {
        Handler(Looper.getMainLooper()).post {
            if (!Settings.canDrawOverlays(c)) return@post
            val wm = c.getSystemService(WindowManager::class.java)
            val box = LinearLayout(c).apply {
                orientation = LinearLayout.VERTICAL; setPadding(48, 48, 48, 48)
                setBackgroundColor(0xF2202124.toInt()); layoutDirection = android.view.View.LAYOUT_DIRECTION_RTL
            }
            fun tv(t: String, sz: Float, col: Int = 0xFFFFFFFF.toInt()) =
                TextView(c).apply { text = t; textSize = sz; setTextColor(col) }
            box.addView(tv(title, 20f, 0xFFFFD54F.toInt()))
            box.addView(tv(body, 16f))
            fun close() = try { wm.removeView(box) } catch (_: Exception) {}
            if (name != null && onSave != null) {
                val et = EditText(c).apply { setText(name); setTextColor(0xFFFFFFFF.toInt()) }
                box.addView(et)
                box.addView(Button(c).apply { text = "حفظ"; setOnClickListener { onSave(et.text.toString()); close() } })
                box.addView(Button(c).apply { text = "تجاهل"; setOnClickListener { close() } })
            } else {
                box.setOnClickListener { close() }
                Handler(Looper.getMainLooper()).postDelayed({ close() }, 20_000)
            }
            val flags = if (onSave == null) WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE else 0
            wm.addView(box, WindowManager.LayoutParams(
                MATCH_PARENT, WRAP_CONTENT, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                flags, PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.TOP
                if (onSave != null) softInputMode = WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE
            })
        }
    }
}

/* ───────────── استقبال المكالمات ───────────── */
/** بيفتح شاشة الملاحظة، وبيسيب إشعار احتياطي لو أندرويد منع الفتح من الخلفية */
fun promptNote(c: Context, num: String) {
    val open = Intent(c, NoteActivity::class.java).putExtra("num", num)
    val nm = c.getSystemService(NotificationManager::class.java)
    nm.createNotificationChannel(NotificationChannel("note", "ملاحظة المكالمة", NotificationManager.IMPORTANCE_HIGH))
    val pi = PendingIntent.getActivity(c, 0, open, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    nm.notify(1, Notification.Builder(c, "note").setSmallIcon(android.R.drawable.ic_btn_speak_now)
        .setContentTitle("سجّل ملخص المكالمة").setContentText(Contacts.name(c, num) ?: num)
        .setContentIntent(pi).setAutoCancel(true).build())
    try { c.startActivity(Intent(open).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    catch (e: Exception) { Log.e("CallBrief", "bg start blocked", e) }
}

class CallReceiver : BroadcastReceiver() {
    companion object { var last = ""; var answered = false }

    override fun onReceive(c: Context, i: Intent) {
        val state = i.getStringExtra(TelephonyManager.EXTRA_STATE) ?: return
        val n = i.getStringExtra(TelephonyManager.EXTRA_INCOMING_NUMBER)
        if (n == null && state == TelephonyManager.EXTRA_STATE_RINGING) return // أول بث بيجي من غير رقم
        Assistant.pausedUntil = when (state) {
            TelephonyManager.EXTRA_STATE_IDLE -> System.currentTimeMillis() + 90_000
            else -> Long.MAX_VALUE
        }
        when (state) {
            TelephonyManager.EXTRA_STATE_RINGING -> if (n != null && n != last) {
                last = n; answered = false
                Pop.show(c, Contacts.name(c, n) ?: n, Store.brief(c, n) ?: "مفيش ملخص سابق")
            }
            TelephonyManager.EXTRA_STATE_OFFHOOK -> answered = true
            TelephonyManager.EXTRA_STATE_IDLE -> {
                val target = last
                val wasAnswered = answered
                last = ""; answered = false
                if (target.isNotEmpty() && wasAnswered) promptNote(c, target)
            }
        }
    }
}

/* ───────────── شاشة الملاحظة الصوتية بعد المكالمة ───────────── */
class NoteActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var tts: TextToSpeech
    private lateinit var status: TextView
    private var sr: SpeechRecognizer? = null
    private val said = StringBuilder()
    private var cur = ""
    private var done = false
    private val h = Handler(Looper.getMainLooper())
    private val num by lazy { intent.getStringExtra("num") ?: "" }
    private val stopWord = Regex("انتهى|انتهي|انتهيت")

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true); setTurnScreenOn(true)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON)
        }
        getSystemService(NotificationManager::class.java).cancel(1)
        Assistant.pausedUntil = Long.MAX_VALUE
        status = TextView(this).apply {
            textSize = 24f; gravity = Gravity.CENTER; setPadding(48, 300, 48, 48)
            text = (Contacts.name(this@NoteActivity, num)?.let { "$it\nقول ملخص المكالمة وبعدين قول: انتهى" }
                ?: "$num (رقم جديد)\nقول الاسم والصفة وملخص المكالمة، وبعدين قول: انتهى")
        }
        setContentView(status)
        tts = TextToSpeech(this, this)
    }

    override fun onInit(s: Int) {
        if (s != TextToSpeech.SUCCESS) { // لو النطق فشل نبدأ الاستماع على طول
            h.postDelayed({ finishNote() }, 45_000)
            h.postDelayed({ listen() }, 600)
            return
        }
        tts.language = Locale("ar", "EG")
        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) {}
            override fun onDone(id: String?) { h.post { listen() } }
            @Deprecated("deprecated") override fun onError(id: String?) { h.post { listen() } }
        })
        val ask = if (Contacts.name(this, num) == null)
            "الرقم ده جديد. قول اسم الشخص وصفته وملخص المكالمة، وبعدين قول انتهى"
        else "قول ملخص المكالمة، وبعدين قول انتهى"
        tts.speak(ask, TextToSpeech.QUEUE_FLUSH, null, "p")
        h.postDelayed({ finishNote() }, 45_000) // حد أقصى 45 ثانية
    }

    private fun listen() {
        if (done) return
        sr?.destroy()
        sr = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onResults(r: Bundle?) = take(r, true)
                override fun onPartialResults(r: Bundle?) = take(r, false)
                override fun onError(e: Int) {
                    if (e == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) finish()
                    else h.postDelayed({ listen() }, 300)
                }
                override fun onReadyForSpeech(p: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(v: Float) {}
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onEvent(t: Int, p: Bundle?) {}
            })
            startListening(
                Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                    .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ar-EG")
                    .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            )
        }
    }

    private fun take(r: Bundle?, final: Boolean) {
        if (done) return
        val t = r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: return
        cur = t
        if (stopWord.containsMatchIn(t)) { said.append(' ').append(t); cur = ""; finishNote(); return }
        if (final) { said.append(' ').append(t); cur = ""; listen() }
    }

    private fun finishNote() {
        if (done) return
        done = true
        h.removeCallbacksAndMessages(null)
        sr?.destroy(); tts.stop()
        val note = "$said $cur".replace(stopWord, "").trim()
        status.text = "بحفظ الملخص..."
        val app = applicationContext
        val n = num
        CoroutineScope(Dispatchers.IO).launch {
            try { Notes.process(app, n, note) } catch (e: Exception) { Log.e("CallBrief", "note failed", e) }
            withContext(Dispatchers.Main) { finish() }
        }
    }

    override fun onDestroy() {
        h.removeCallbacksAndMessages(null)
        sr?.destroy(); tts.shutdown()
        Assistant.pausedUntil = System.currentTimeMillis() + 1500
        super.onDestroy()
    }
}

/* ───────────── الاتصال بالأمر الصوتي ───────────── */
object Dial {
    private val re = Regex("(?:اتصل|كلم|رن)\\s+(?:على\\s+|ب)?(.+?)(?:\\s+(?:(?:على|ع|من)\\s+)?(?:ال)?(?:شريح|سيم|خط|اورانج|أورانج|فودافون).*)?$")

    fun run(c: Context, said: String) {
        val s = said.lowercase()
        val slot = when {
            Regex("واحد|1|١|اورانج|أورانج|orange").containsMatchIn(s) -> 0
            Regex("اتنين|اثنين|2|٢|فودافون|vodafone").containsMatchIn(s) -> 1
            else -> 0
        }
        val name = re.find(said.trim())?.groupValues?.get(1)?.trim()
        val num = name?.let { Contacts.numberOf(c, it) }
        if (num == null) { Toast.makeText(c, "مش لاقي: $name", Toast.LENGTH_LONG).show(); return }
        val msg = call(c, num, slot)
        if (msg != "الاتصال بدأ") Toast.makeText(c, msg, Toast.LENGTH_LONG).show()
    }

    @SuppressLint("MissingPermission")
    fun call(c: Context, num: String, slot: Int): String {
        val tm = c.getSystemService(TelecomManager::class.java)
        val sub = c.getSystemService(SubscriptionManager::class.java)
            .activeSubscriptionInfoList?.firstOrNull { it.simSlotIndex == slot }
        val accounts = tm.callCapablePhoneAccounts
        val handle = accounts.firstOrNull { sub != null && it.id == sub.subscriptionId.toString() }
        if (handle == null) {
            Log.e("CallBrief", "accounts=${accounts.map { it.id }} slot=$slot sub=${sub?.subscriptionId}")
            return "مش لاقي الشريحة ${slot + 1}"
        }
        CallReceiver.last = num; CallReceiver.answered = false // عشان نسأل عن الملخص بعد المكالمة الصادرة كمان
        c.startActivity(
            Intent(Intent.ACTION_CALL, Uri.fromParts("tel", num, null))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                .putExtra(TelecomManager.EXTRA_PHONE_ACCOUNT_HANDLE, handle)
        )
        return "الاتصال بدأ"
    }
}

/* ───────────── الواجهة ───────────── */
class MainActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        requestPermissions(arrayOf(
            "android.permission.READ_PHONE_STATE", "android.permission.READ_CALL_LOG",
            "android.permission.READ_CONTACTS", "android.permission.WRITE_CONTACTS",
            "android.permission.CALL_PHONE", "android.permission.READ_SMS",
            "android.permission.READ_PHONE_NUMBERS", "android.permission.RECORD_AUDIO",
            "android.permission.POST_NOTIFICATIONS"
        ), 1)

        val mic = Button(this).apply {
            text = "🎤 اتكلم"; textSize = 28f
            setOnClickListener {
                startActivityForResult(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ar-EG")
                }, 7)
            }
        }
        val waBtn = Button(this).apply {
            text = "فعّل صلاحية قراءة إشعارات الواتساب"
            setOnClickListener { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }
        }
        val key = EditText(this).apply {
            hint = "مفتاح Anthropic API"; setText(Store.cfg(this@MainActivity, "key"))
            doAfterTextChanged { Store.setCfg(this@MainActivity, "key", it.toString()) }
        }
        var on = false
        val hamoudi = Button(this).apply {
            text = "▶ شغّل حمودي (وضع الاستعداد)"
            setOnClickListener {
                val svc = Intent(this@MainActivity, HamoudiService::class.java)
                if (!on) {
                    if (checkSelfPermission("android.permission.RECORD_AUDIO") != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                        Toast.makeText(this@MainActivity, "وافق على صلاحية الميكروفون الأول", Toast.LENGTH_LONG).show(); return@setOnClickListener
                    }
                    this@MainActivity.startForegroundService(svc); text = "⏹ أوقف حمودي"; on = true
                } else { this@MainActivity.stopService(svc); text = "▶ شغّل حمودي (وضع الاستعداد)"; on = false }
            }
        }
        val city = EditText(this).apply {
            hint = "مدينتك (للطقس)"; setText(Store.cfg(this@MainActivity, "city"))
            doAfterTextChanged { Store.setCfg(this@MainActivity, "city", it.toString()) }
        }
        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(48, 96, 48, 48)
            addView(mic, LinearLayout.LayoutParams(MATCH_PARENT, 400))
            addView(hamoudi); addView(waBtn); addView(city); addView(key)
        })
    }

    override fun onResume() {
        super.onResume()
        if (!Settings.canDrawOverlays(this))
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
    }

    override fun onActivityResult(rc: Int, res: Int, d: Intent?) {
        if (rc == 7 && res == RESULT_OK)
            d?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()?.let { Dial.run(this, it) }
    }
}
