package com.example.callbrief

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.AlarmClock
import android.provider.ContactsContract.CommonDataKinds.Phone
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Base64
import android.util.Log
import android.widget.Toast
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.text.SimpleDateFormat
import java.time.LocalDateTime
import java.time.ZoneId
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.concurrent.TimeUnit

/* بيوقف حمودي أثناء المكالمات وشاشة الملاحظة عشان الميكروفون */
object Assistant {
    @Volatile var pausedUntil = 0L
    fun paused() = System.currentTimeMillis() < pausedUntil
}

/* ───────────── Gemini (مفتاح مجاني من Google AI Studio) ───────────── */
class RateLimit : RuntimeException()

object Gemini {
    const val MODEL = "gemini-2.5-flash"
    private val http = OkHttpClient.Builder().readTimeout(60, TimeUnit.SECONDS).build()

    fun call(c: Context, body: JSONObject): JSONObject {
        val req = Request.Builder()
            .url("https://generativelanguage.googleapis.com/v1beta/models/$MODEL:generateContent")
            .header("x-goog-api-key", Store.cfg(c, "gkey").trim())
            .post(body.toString().toRequestBody("application/json".toMediaType())).build()
        http.newCall(req).execute().use { r ->
            val raw = r.body?.string() ?: ""
            if (r.code == 429) throw RateLimit()
            if (!r.isSuccessful) throw RuntimeException("HTTP ${r.code}: $raw")
            return JSONObject(raw)
        }
    }

    fun text(resp: JSONObject): String {
        val parts = resp.optJSONArray("candidates")?.optJSONObject(0)
            ?.optJSONObject("content")?.optJSONArray("parts") ?: return ""
        val sb = StringBuilder()
        for (i in 0 until parts.length()) {
            val p = parts.getJSONObject(i)
            if (!p.optBoolean("thought", false)) sb.append(p.optString("text"))
        }
        return sb.toString()
    }

    // بحث جوجل الحقيقي (للطقس والأخبار والمعلومات الحديثة)
    fun search(c: Context, q: String): String {
        val body = JSONObject()
            .put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts",
                JSONArray().put(JSONObject().put("text", "$q\nجاوب بالعربي بإيجاز ودقة ومعاك الأرقام.")))))
            .put("tools", JSONArray().put(JSONObject().put("google_search", JSONObject())))
        return text(call(c, body)).ifBlank { "ملقتش نتيجة" }
    }
}

/* ───────────── تسجيل أمرك الصوتي (بدون أي صوت دينج) ───────────── */
object Voice {
    fun wav(pcm: ByteArray, rate: Int): ByteArray {
        val h = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
        h.put("RIFF".toByteArray()).putInt(36 + pcm.size).put("WAVE".toByteArray()).put("fmt ".toByteArray())
            .putInt(16).putShort(1.toShort()).putShort(1.toShort()).putInt(rate).putInt(rate * 2)
            .putShort(2.toShort()).putShort(16.toShort()).put("data".toByteArray()).putInt(pcm.size)
        return h.array() + pcm
    }

    // بيسجل لحد ما تسكت ثانية، أو 12 ثانية كحد أقصى. بيرجّع null لو محدش اتكلم.
    @android.annotation.SuppressLint("MissingPermission")
    fun record(abort: () -> Boolean): ByteArray? {
        val rate = 16000
        val min = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val rec = AudioRecord(MediaRecorder.AudioSource.MIC, rate, AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT, maxOf(min, 8192))
        if (rec.state != AudioRecord.STATE_INITIALIZED) { rec.release(); return null }
        val out = ByteArrayOutputStream()
        val buf = ShortArray(320) // 20ms
        var noise = 0.0; var n = 0; var speech = false; var quiet = 0
        val t0 = System.currentTimeMillis()
        rec.startRecording()
        try {
            while (System.currentTimeMillis() - t0 < 12_000) {
                if (abort()) return null
                val r = rec.read(buf, 0, buf.size)
                if (r <= 0) continue
                var sum = 0.0
                for (i in 0 until r) sum += buf[i] * buf[i].toDouble()
                val rms = Math.sqrt(sum / r)
                val bb = ByteBuffer.allocate(r * 2).order(ByteOrder.LITTLE_ENDIAN)
                for (i in 0 until r) bb.putShort(buf[i])
                out.write(bb.array())
                if (n < 15) { noise = if (n == 0) rms else minOf(noise, rms); n++; continue }
                if (rms > maxOf(600.0, noise * 3)) { speech = true; quiet = 0 } else if (speech) quiet++
                if (speech && quiet > 50) break
                if (!speech && System.currentTimeMillis() - t0 > 6_000) return null
            }
        } finally { rec.stop(); rec.release() }
        return if (speech) wav(out.toByteArray(), rate) else null
    }
}

/* ───────────── كلمة التنبيه "حمودي" بصوتك إنت: على التابلت نفسه، من غير حساب ولا دينج ───────────── */
object WakeWord {
    private const val RATE = 16000
    private const val FRAME = 400
    private const val HOP = 160
    private const val NFFT = 512
    private const val NMEL = 26
    private const val DIMS = 12
    private val window = DoubleArray(FRAME) { 0.54 - 0.46 * Math.cos(2 * Math.PI * it / (FRAME - 1)) }
    private val melBank: Array<FloatArray> = buildMel()
    private val dct: Array<DoubleArray> =
        Array(DIMS + 1) { c -> DoubleArray(NMEL) { m -> Math.cos(Math.PI * c * (m + 0.5) / NMEL) } }
    private var cache: Pair<List<Array<FloatArray>>, Float>? = null

    private fun buildMel(): Array<FloatArray> {
        fun hz2mel(f: Double) = 2595 * Math.log10(1 + f / 700)
        fun mel2hz(m: Double) = 700 * (Math.pow(10.0, m / 2595) - 1)
        val lo = hz2mel(100.0); val hi = hz2mel(4000.0)
        val pts = DoubleArray(NMEL + 2) { mel2hz(lo + (hi - lo) * it / (NMEL + 1)) }
        val bin = IntArray(NMEL + 2) { Math.floor((NFFT + 1) * pts[it] / RATE).toInt() }
        return Array(NMEL) { m ->
            val fb = FloatArray(NFFT / 2 + 1)
            for (k in bin[m] until bin[m + 1]) fb[k] = (k - bin[m]).toFloat() / maxOf(1, bin[m + 1] - bin[m])
            for (k in bin[m + 1] until bin[m + 2]) fb[k] = (bin[m + 2] - k).toFloat() / maxOf(1, bin[m + 2] - bin[m + 1])
            fb
        }
    }

    private fun fft(re: DoubleArray, im: DoubleArray) {
        val n = re.size
        var j = 0
        for (i in 1 until n) {
            var bit = n shr 1
            while ((j and bit) != 0) { j = j xor bit; bit = bit shr 1 }
            j = j xor bit
            if (i < j) {
                val tr = re[i]; re[i] = re[j]; re[j] = tr
                val ti = im[i]; im[i] = im[j]; im[j] = ti
            }
        }
        var len = 2
        while (len <= n) {
            val ang = -2 * Math.PI / len
            val wr = Math.cos(ang); val wi = Math.sin(ang)
            var i = 0
            while (i < n) {
                var cr = 1.0; var ci = 0.0
                for (k in 0 until len / 2) {
                    val a = i + k; val b = i + k + len / 2
                    val vr = re[b] * cr - im[b] * ci
                    val vi = re[b] * ci + im[b] * cr
                    re[b] = re[a] - vr; im[b] = im[a] - vi
                    re[a] = re[a] + vr; im[a] = im[a] + vi
                    val ncr = cr * wr - ci * wi
                    ci = cr * wi + ci * wr; cr = ncr
                }
                i += len
            }
            len = len shl 1
        }
    }

    // بصمة صوتية للكلمة: MFCC بعد طرح المتوسط (بتتجاهل علو الصوت)
    fun mfcc(x: ShortArray): Array<FloatArray> {
        val s = DoubleArray(x.size)
        for (i in x.indices) s[i] = x[i] - (if (i > 0) 0.97 * x[i - 1] else 0.0)
        val nF = if (s.size < FRAME) 0 else 1 + (s.size - FRAME) / HOP
        val out = Array(nF) { FloatArray(DIMS) }
        val re = DoubleArray(NFFT); val im = DoubleArray(NFFT); val mel = DoubleArray(NMEL)
        for (f in 0 until nF) {
            java.util.Arrays.fill(re, 0.0); java.util.Arrays.fill(im, 0.0)
            for (i in 0 until FRAME) re[i] = s[f * HOP + i] * window[i]
            fft(re, im)
            for (m in 0 until NMEL) {
                var e = 0.0
                val fb = melBank[m]
                for (k in fb.indices) { val w = fb[k]; if (w != 0f) e += w * (re[k] * re[k] + im[k] * im[k]) }
                mel[m] = Math.log(e + 1e-3)
            }
            for (c in 1..DIMS) {
                var v = 0.0
                for (m in 0 until NMEL) v += mel[m] * dct[c][m]
                out[f][c - 1] = v.toFloat()
            }
        }
        if (nF > 0) for (d in 0 until DIMS) {
            var mean = 0.0
            for (f in 0 until nF) mean += out[f][d]
            mean /= nF
            for (f in 0 until nF) out[f][d] -= mean.toFloat()
        }
        return out
    }

    private fun dtw(a: Array<FloatArray>, b: Array<FloatArray>): Double {
        val n = a.size; val m = b.size
        if (n == 0 || m == 0) return 1e9
        val band = maxOf(Math.abs(n - m), maxOf(n, m) / 3) + 1
        val inf = 1e18
        var prev = DoubleArray(m + 1) { inf }
        var cur = DoubleArray(m + 1)
        prev[0] = 0.0
        for (i in 1..n) {
            java.util.Arrays.fill(cur, inf)
            val j0 = maxOf(1, i - band); val j1 = minOf(m, i + band)
            for (j in j0..j1) {
                var d = 0.0
                val x = a[i - 1]; val y = b[j - 1]
                for (k in x.indices) { val t = (x[k] - y[k]).toDouble(); d += t * t }
                cur[j] = Math.sqrt(d) + minOf(prev[j], minOf(prev[j - 1], cur[j - 1]))
            }
            val t = prev; prev = cur; cur = t
        }
        return prev[m] / (n + m)
    }

    fun enrolled(c: Context) = File(c.filesDir, "wake.bin").exists()

    fun save(c: Context, segs: List<ShortArray>): Boolean {
        val t = segs.map { mfcc(it) }.filter { it.size in 25..140 }
        if (t.size < 3) return false
        var worst = 0.0
        for (i in t.indices) {
            var best = 1e9
            for (j in t.indices) if (i != j) best = minOf(best, dtw(t[i], t[j]))
            worst = maxOf(worst, best)
        }
        val thr = (worst * 1.4).toFloat()
        DataOutputStream(File(c.filesDir, "wake.bin").outputStream().buffered()).use { o ->
            o.writeInt(t.size); o.writeFloat(thr)
            for (a in t) { o.writeInt(a.size); for (fr in a) for (v in fr) o.writeFloat(v) }
        }
        cache = null
        return true
    }

    private fun load(c: Context): Pair<List<Array<FloatArray>>, Float>? {
        cache?.let { return it }
        val f = File(c.filesDir, "wake.bin")
        if (!f.exists()) return null
        DataInputStream(f.inputStream().buffered()).use { i ->
            val n = i.readInt(); val thr = i.readFloat()
            val ts = List(n) { val fr = i.readInt(); Array(fr) { FloatArray(DIMS) { i.readFloat() } } }
            cache = ts to thr
        }
        return cache
    }

    @android.annotation.SuppressLint("MissingPermission")
    private fun open(): AudioRecord? {
        val min = AudioRecord.getMinBufferSize(RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val rec = AudioRecord(MediaRecorder.AudioSource.VOICE_RECOGNITION, RATE, AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT, maxOf(min, 16384))
        if (rec.state != AudioRecord.STATE_INITIALIZED) { rec.release(); return null }
        return rec
    }

    private fun flatten(frames: List<ShortArray>): ShortArray {
        val out = ShortArray(frames.sumOf { it.size })
        var p = 0
        for (f in frames) { System.arraycopy(f, 0, out, p, f.size); p += f.size }
        return out
    }

    // بيستنى لحد ما يلاقي جملة قصيرة (0.3 لـ 1.4 ثانية) بين سكوتين، وبيقفل الميكروفون قبل ما يرجّعها
    private fun nextSegment(run: () -> Boolean): ShortArray? {
        val rec = open() ?: return null
        val buf = ShortArray(320) // 20ms
        val pre = kotlin.collections.ArrayDeque<ShortArray>()
        val seg = ArrayList<ShortArray>()
        var floor = 300.0; var inSeg = false; var quiet = 0; var loud = 0
        rec.startRecording()
        try {
            while (run()) {
                val n = rec.read(buf, 0, buf.size)
                if (n <= 0) continue
                val fr = buf.copyOf(n)
                var sum = 0.0
                for (v in fr) sum += v * v.toDouble()
                val rms = Math.sqrt(sum / n)
                val th = maxOf(floor * 3.0, 400.0)
                if (!inSeg) {
                    if (rms < th) floor = floor * 0.98 + rms * 0.02
                    pre.addLast(fr); if (pre.size > 5) pre.removeFirst()
                    if (rms > th) {
                        loud++
                        if (loud >= 2) { inSeg = true; quiet = 0; seg.clear(); seg.addAll(pre) }
                    } else loud = 0
                } else {
                    seg.add(fr)
                    if (rms > th) quiet = 0 else quiet++
                    if (quiet >= 12 || seg.size > 75) {
                        val dur = seg.size - quiet
                        if (dur in 15..70) return flatten(seg.subList(0, minOf(seg.size, dur + 2)))
                        inSeg = false; loud = 0; pre.clear(); seg.clear()
                    }
                }
            }
        } finally { rec.stop(); rec.release() }
        return null
    }

    // للتسجيل: بيلتقط كلمة واحدة (أو null بعد 7 ثواني من غير كلام)
    fun captureWord(): ShortArray? {
        val end = System.currentTimeMillis() + 7000
        return nextSegment { System.currentTimeMillis() < end }
    }

    // لو شبه الكلمة، بنتأكد من جيميني (مقطع أقل من ثانيتين بس) عشان نقلل الإنذارات الغلط
    private fun verify(c: Context, pcm: ShortArray): Boolean = try {
        val bb = ByteBuffer.allocate(pcm.size * 2).order(ByteOrder.LITTLE_ENDIAN)
        for (v in pcm) bb.putShort(v)
        val wav = Voice.wav(bb.array(), RATE)
        val parts = JSONArray()
            .put(JSONObject().put("inlineData", JSONObject().put("mimeType", "audio/wav")
                .put("data", Base64.encodeToString(wav, Base64.NO_WRAP))))
            .put(JSONObject().put("text", "هل الكلمة المنطوقة في التسجيل هي \"حمودي\" أو نطق قريب جدًا منها؟ رد بكلمة واحدة: نعم أو لا."))
        val body = JSONObject().put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", parts)))
            .put("generationConfig", JSONObject().put("maxOutputTokens", 30)
                .put("thinkingConfig", JSONObject().put("thinkingBudget", 0)))
        Gemini.text(Gemini.call(c, body)).contains("نعم")
    } catch (e: Exception) { Log.e("CallBrief", "verify failed", e); true }

    fun listen(c: Context, run: () -> Boolean): Boolean {
        val (temps, thr) = load(c) ?: return false
        val verifyOn = Store.cfg(c, "gkey").isNotBlank()
        val limit = thr * (if (verifyOn) 1.3 else 1.0)
        while (run()) {
            val pcm = nextSegment(run)
            if (pcm == null) { if (run()) Thread.sleep(500); continue }
            val f = mfcc(pcm)
            if (f.size !in 25..140) continue
            val d = temps.minOf { dtw(f, it) }
            if (d < limit && (!verifyOn || verify(c, pcm))) return true
        }
        return false
    }
}

/* ───────────── التطبيقات المثبتة ───────────── */
object Apps {
    private fun list(c: Context) = c.packageManager
        .queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        .map { it.loadLabel(c.packageManager).toString() to it.activityInfo.packageName }

    fun labels(c: Context) = list(c).map { it.first }.distinct().sorted().take(120)

    fun open(c: Context, label: String): String {
        val l = label.lowercase()
        val all = list(c)
        val hit = all.firstOrNull { it.first.lowercase() == l }
            ?: all.firstOrNull { it.first.lowercase().contains(l) } ?: return "مش لاقي تطبيق بالاسم ده"
        val i = c.packageManager.getLaunchIntentForPackage(hit.second) ?: return "مقدرتش أفتحه"
        c.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return "فتحت ${hit.first}"
    }
}

/* ───────────── التذكيرات ───────────── */
class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val nm = c.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("remind", "تذكيرات حمودي", NotificationManager.IMPORTANCE_HIGH))
        nm.notify(i.getIntExtra("id", 0), Notification.Builder(c, "remind")
            .setSmallIcon(android.R.drawable.ic_popup_reminder).setContentTitle("تذكير")
            .setContentText(i.getStringExtra("text") ?: "").setAutoCancel(true).build())
    }
}

/* ───────────── الأدوات اللي الـ Agent بينفذها على التابلت ───────────── */
object Tools {
    // توحيد الحروف العربية عشان البحث يمسك أحمد/احمد وفاطمة/فاطمه... إلخ
    fun norm(s: String) = s.lowercase()
        .replace(Regex("[\\u064B-\\u065F\\u0670\\u0640]"), "")
        .replace(Regex("[أإآ]"), "ا").replace('ى', 'ي').replace('ة', 'ه')
        .replace('ؤ', 'و').replace('ئ', 'ي').trim()

    private fun allContacts(c: Context): List<Pair<String, String>> {
        val out = LinkedHashMap<String, String>() // الرقم -> الاسم
        c.contentResolver.query(Phone.CONTENT_URI, arrayOf(Phone.DISPLAY_NAME, Phone.NUMBER), null, null, null)?.use {
            while (it.moveToNext()) {
                val num = it.getString(1)?.filter { ch -> ch.isDigit() || ch == '+' } ?: continue
                out.putIfAbsent(num, it.getString(0) ?: "")
            }
        }
        return out.map { it.value to it.key }
    }

    private fun reminder(c: Context, dt: String, text: String): String {
        val at = LocalDateTime.parse(dt.trim()).atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
        if (at <= System.currentTimeMillis()) return "الوقت ده عدّى"
        val id = (at / 1000 % 1_000_000).toInt()
        val pi = PendingIntent.getBroadcast(c, id,
            Intent(c, ReminderReceiver::class.java).putExtra("text", text).putExtra("id", id),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val am = c.getSystemService(AlarmManager::class.java)
        if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms())
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi) // تقريبي لو الإذن مش متفعل
        else am.setAlarmClock(AlarmManager.AlarmClockInfo(at,
            PendingIntent.getActivity(c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)), pi)
        return "اتضبط التذكير"
    }

    fun run(c: Context, name: String, a: JSONObject): String = try {
        when (name) {
            "find_contact" -> {
                val arr = a.getJSONArray("names")
                val qs = (0 until arr.length()).map { norm(arr.getString(it)) }.filter { it.length >= 2 }
                val hits = allContacts(c).filter { (n, _) -> val nn = norm(n); qs.any { nn.contains(it) } }.take(5)
                if (hits.isEmpty()) "مفيش جهة اتصال بالاسم ده" else hits.joinToString("\n") { "${it.first} | ${it.second}" }
            }
            "call_contact" -> Dial.call(c, a.getString("number"), a.optInt("sim", 1) - 1)
            "open_app" -> Apps.open(c, a.getString("label"))
            "set_alarm" -> {
                c.startActivity(Intent(AlarmClock.ACTION_SET_ALARM)
                    .putExtra(AlarmClock.EXTRA_HOUR, a.getInt("hour")).putExtra(AlarmClock.EXTRA_MINUTES, a.getInt("minute"))
                    .putExtra(AlarmClock.EXTRA_MESSAGE, a.optString("label", "")).putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                "تم ضبط المنبه"
            }
            "set_timer" -> {
                c.startActivity(Intent(AlarmClock.ACTION_SET_TIMER)
                    .putExtra(AlarmClock.EXTRA_LENGTH, a.getInt("seconds")).putExtra(AlarmClock.EXTRA_MESSAGE, a.optString("label", ""))
                    .putExtra(AlarmClock.EXTRA_SKIP_UI, true).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                "اتضبط المؤقت"
            }
            "set_reminder" -> reminder(c, a.getString("datetime"), a.getString("text"))
            "save_note" -> {
                val d = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date())
                File(c.filesDir, "notes.txt").appendText("[$d] ${a.getString("text")}\n")
                "اتحفظت الملاحظة"
            }
            "web_search" -> Gemini.search(c, a.getString("query"))
            else -> "أداة مش معروفة"
        }
    } catch (e: RateLimit) { throw e }
    catch (e: Exception) { Log.e("CallBrief", "tool $name failed", e); "فشل: ${e.message}" }
}

/* ───────────── الـ Agent (Gemini يسمع الصوت مباشرة ويستخدم الأدوات) ───────────── */
object Agent {
    private val hist = ArrayList<JSONObject>() // محادثة نصية قصيرة للمتابعة
    private var lastAt = 0L

    private fun str(d: String) = JSONObject().put("type", "STRING").put("description", d)
    private fun num(d: String) = JSONObject().put("type", "INTEGER").put("description", d)
    private fun decl(name: String, desc: String, props: JSONObject, req: List<String>) =
        JSONObject().put("name", name).put("description", desc).put("parameters",
            JSONObject().put("type", "OBJECT").put("properties", props).put("required", JSONArray(req)))

    private fun fns() = JSONArray()
        .put(decl("find_contact", "دور في جهات الاتصال. ابعت كل احتمالات الاسم بالعربي والإنجليزي.",
            JSONObject().put("names", JSONObject().put("type", "ARRAY").put("items", JSONObject().put("type", "STRING"))), listOf("names")))
        .put(decl("call_contact", "اتصل برقم. sim=1 أو 2.",
            JSONObject().put("number", str("الرقم")).put("sim", num("رقم الشريحة")), listOf("number")))
        .put(decl("open_app", "افتح تطبيق باسمه زي ما هو في قايمة التطبيقات.",
            JSONObject().put("label", str("اسم التطبيق")), listOf("label")))
        .put(decl("set_alarm", "اضبط منبه بالساعة (24) والدقيقة.",
            JSONObject().put("hour", num("0-23")).put("minute", num("0-59")).put("label", str("اسم المنبه")), listOf("hour", "minute")))
        .put(decl("set_timer", "اضبط مؤقت بالثواني.",
            JSONObject().put("seconds", num("المدة بالثواني")).put("label", str("اسم المؤقت")), listOf("seconds")))
        .put(decl("set_reminder", "اضبط تذكير في وقت محدد (ممكن بعد أيام).",
            JSONObject().put("datetime", str("بصيغة 2026-11-09T09:00 بالتوقيت المحلي")).put("text", str("نص التذكير")), listOf("datetime", "text")))
        .put(decl("save_note", "احفظ ملاحظة نصية.", JSONObject().put("text", str("نص الملاحظة")), listOf("text")))
        .put(decl("web_search", "ابحث في جوجل: الطقس، الأخبار، الأسعار، أي معلومة حديثة أو مش متأكد منها.",
            JSONObject().put("query", str("نص البحث")), listOf("query")))

    private fun system(c: Context): String {
        val now = SimpleDateFormat("EEEE yyyy-MM-dd HH:mm", Locale.US).format(Date())
        val city = Store.cfg(c, "city").ifBlank { "القاهرة" }
        return """أنت "حمودي"، مساعد صوتي شخصي بيتكلم مصري. أمر المستخدم بيوصلك كملف صوتي بالعربي المصري، وممكن فيه أسماء أو كلمات إنجليزي، فافهمه بدقة. ابدأ ردك النهائي دايمًا بسطر بالشكل ده بالظبط: [سمعت: نص كلام المستخدم] وبعده الرد في سطر جديد. الرد بيتنطق بصوت عالي، فخليه قصير وطبيعي: جملة أو اتنين، من غير رموز ولا markdown ولا إيموجي. الوقت دلوقتي: $now (${TimeZone.getDefault().id}). مدينة المستخدم: $city. الشريحة 1 = اورانج، الشريحة 2 = فودافون، والافتراضي 1. للطقس والأخبار والأسعار وأي معلومة حديثة أو مش متأكد منها استخدم web_search وجاوب بدقة وبالأرقام. للحسابات اشتغل خطوة خطوة وراجع الناتج. للاتصال: ابدأ بـ find_contact وابعت الاسم بالعربي والإنجليزي، ولو لقيت أكتر من واحد اسأل المستخدم مين، وبعدين call_contact. لفتح تطبيق اختار اسمه بالظبط من القايمة دي: ${Apps.labels(c).joinToString(", ")}. بعد تنفيذ أي أمر قول بجملة قصيرة إنك عملته. لو الصوت مش مفهوم اطلب منه يعيد."""
    }

    fun ask(c: Context, wav: ByteArray): String {
        if (System.currentTimeMillis() - lastAt > 120_000) hist.clear()
        val contents = JSONArray()
        hist.forEach { contents.put(it) }
        contents.put(JSONObject().put("role", "user").put("parts", JSONArray()
            .put(JSONObject().put("inlineData", JSONObject().put("mimeType", "audio/wav")
                .put("data", Base64.encodeToString(wav, Base64.NO_WRAP))))
            .put(JSONObject().put("text", "ده أمري الصوتي."))))
        var out = ""
        for (k in 0 until 6) {
            val body = JSONObject()
                .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system(c)))))
                .put("contents", contents)
                .put("tools", JSONArray().put(JSONObject().put("functionDeclarations", fns())))
                .put("generationConfig", JSONObject().put("maxOutputTokens", 2048))
            val resp = Gemini.call(c, body)
            val content = resp.optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content") ?: break
            contents.put(content)
            val parts = content.optJSONArray("parts") ?: break
            val calls = (0 until parts.length()).map { parts.getJSONObject(it) }.filter { it.has("functionCall") }
            if (calls.isEmpty()) { out = Gemini.text(resp); break }
            val results = JSONArray()
            for (p in calls) {
                val fc = p.getJSONObject("functionCall")
                val r = Tools.run(c, fc.getString("name"), fc.optJSONObject("args") ?: JSONObject())
                results.put(JSONObject().put("functionResponse",
                    JSONObject().put("name", fc.getString("name")).put("response", JSONObject().put("result", r))))
            }
            contents.put(JSONObject().put("role", "user").put("parts", results))
        }
        val m = Regex("^\\s*\\[سمعت:\\s*(.*?)\\]\\s*", RegexOption.DOT_MATCHES_ALL).find(out)
        val heard = m?.groupValues?.get(1)?.trim().orEmpty().ifBlank { "(أمر صوتي)" }
        val reply = (if (m != null) out.substring(m.range.last + 1) else out)
            .replace(Regex("[*#_`]"), "").trim().ifBlank { "تمام" }
        hist.add(JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", heard))))
        hist.add(JSONObject().put("role", "model").put("parts", JSONArray().put(JSONObject().put("text", reply))))
        while (hist.size > 8) { hist.removeAt(0); hist.removeAt(0) }
        lastAt = System.currentTimeMillis()
        return reply
    }
}

/* ───────────── خدمة "حمودي": كلمة تنبيه بصوتك على التابلت بدون صوت دينج ───────────── */
class HamoudiService : Service(), TextToSpeech.OnInitListener {
    private val h = Handler(Looper.getMainLooper())
    private lateinit var tts: TextToSpeech
    private var ttsReady = false
    private var wakeThread: Thread? = null
    @Volatile private var wakeRun = false
    private var wakeOn = false
    private var speaking = false
    @Volatile private var cmdListening = false
    @Volatile private var working = false
    private var afterSpeak: (() -> Unit)? = null

    // بيرجّع وضع الاستعداد لوحده بعد أي أمر، وبيقفله أثناء المكالمات
    private val tick = object : Runnable {
        override fun run() {
            if (Assistant.paused()) stopWake() else startWake()
            h.postDelayed(this, 1000)
        }
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel("hamoudi", "حمودي", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "hamoudi").setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("حمودي شغال").setContentText("قول: حمودي").build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(2, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        else startForeground(2, n)
        tts = TextToSpeech(this, this)
    }

    override fun onStartCommand(i: Intent?, f: Int, id: Int) = START_STICKY

    override fun onInit(s: Int) {
        ttsReady = s == TextToSpeech.SUCCESS
        if (ttsReady) {
            tts.language = Locale("ar", "EG")
            tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(id: String?) {}
                override fun onDone(id: String?) { h.post { finishSpeak() } }
                @Deprecated("deprecated") override fun onError(id: String?) { h.post { finishSpeak() } }
            })
        }
        h.post(tick)
    }

    private fun startWake() {
        if (wakeOn || speaking || working || cmdListening || Assistant.paused()) return
        if (!WakeWord.enrolled(this)) {
            Toast.makeText(this, "سجّل كلمة حمودي من التطبيق الأول", Toast.LENGTH_LONG).show()
            stopSelf(); return
        }
        wakeOn = true; wakeRun = true
        wakeThread = Thread {
            val hit = try { WakeWord.listen(this) { wakeRun } } catch (e: Exception) {
                Log.e("CallBrief", "wake failed", e); false
            }
            if (hit) h.post { onWake() } else if (wakeRun) h.post { wakeOn = false }
        }.also { it.start() }
    }

    private fun stopWake() {
        wakeRun = false
        try { wakeThread?.join(800) } catch (e: InterruptedException) { }
        wakeThread = null
        wakeOn = false
    }

    private fun onWake() {
        if (!wakeOn) return
        stopWake()
        speak("أيوه") { h.postDelayed({ listenCommand() }, 250) }
    }

    private fun finishSpeak() {
        speaking = false
        val a = afterSpeak; afterSpeak = null
        a?.invoke()
    }

    private fun speak(t: String, after: () -> Unit) {
        if (!ttsReady) { after(); return }
        speaking = true; afterSpeak = after
        if (tts.speak(t, TextToSpeech.QUEUE_FLUSH, null, "u") == TextToSpeech.ERROR) { speaking = false; after() }
    }

    // بنسجّل صوتك بنفسنا (من غير صوت دينج) ونبعته لـ Gemini يفهمه وينفذه
    private fun listenCommand() {
        if (Assistant.paused() || cmdListening) return
        stopWake()
        cmdListening = true
        Thread {
            val wav = try { Voice.record { Assistant.paused() } } catch (e: Exception) {
                Log.e("CallBrief", "record failed", e); null
            }
            h.post { cmdListening = false; if (wav != null) handle(wav) }
        }.start()
    }

    private fun handle(wav: ByteArray) {
        working = true
        Thread {
            val reply = try { Agent.ask(this, wav) }
            catch (e: RateLimit) { "الحد المجاني خلص دقيقة، جرّب كمان شوية" }
            catch (e: Exception) { Log.e("CallBrief", "agent failed", e); "حصلت مشكلة، جرّب تاني" }
            h.post {
                working = false
                val q = reply.trimEnd().let { it.endsWith("؟") || it.endsWith("?") }
                speak(reply) { if (q) h.postDelayed({ listenCommand() }, 250) }
            }
        }.start()
    }

    override fun onDestroy() {
        h.removeCallbacksAndMessages(null)
        stopWake()
        if (ttsReady) tts.shutdown()
        super.onDestroy()
    }
}
