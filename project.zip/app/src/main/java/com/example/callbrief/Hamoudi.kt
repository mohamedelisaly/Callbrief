package com.example.callbrief

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.AlarmClock
import android.provider.ContactsContract.CommonDataKinds.Phone
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

/* بيوقف حمودي أثناء المكالمات وشاشة الملاحظة عشان الميكروفون */
object Assistant {
    @Volatile var pausedUntil = 0L
    fun paused() = System.currentTimeMillis() < pausedUntil
}

/* ───────────── التطبيقات المثبتة ───────────── */
object Apps {
    private fun list(c: Context) = c.packageManager
        .queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        .map { it.loadLabel(c.packageManager).toString() to it.activityInfo.packageName }

    fun labels(c: Context) = list(c).map { it.first }.distinct().sorted().take(120)

    fun open(c: Context, label: String): String {
        val l = label.lowercase()
        val all = list(c)
        val hit = all.firstOrNull { it.first.lowercase() == l }
            ?: all.firstOrNull { it.first.lowercase().contains(l) } ?: return "مش لاقي تطبيق بالاسم ده"
        val i = c.packageManager.getLaunchIntentForPackage(hit.second) ?: return "مقدرتش أفتحه"
        c.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return "فتحت ${hit.first}"
    }
}

/* ───────────── الأدوات اللي الـ Agent بينفذها على التابلت ───────────── */
object Tools {
    // توحيد الحروف العربية عشان البحث يمسك أحمد/احمد وفاطمة/فاطمه... إلخ
    fun norm(s: String) = s.lowercase()
        .replace(Regex("[\\u064B-\\u065F\\u0670\\u0640]"), "")
        .replace(Regex("[أإآ]"), "ا").replace('ى', 'ي').replace('ة', 'ه')
        .replace('ؤ', 'و').replace('ئ', 'ي').trim()

    private fun allContacts(c: Context): List<Pair<String, String>> {
        val out = LinkedHashMap<String, String>() // الرقم -> الاسم
        c.contentResolver.query(Phone.CONTENT_URI, arrayOf(Phone.DISPLAY_NAME, Phone.NUMBER), null, null, null)?.use {
            while (it.moveToNext()) {
                val num = it.getString(1)?.filter { ch -> ch.isDigit() || ch == '+' } ?: continue
                out.putIfAbsent(num, it.getString(0) ?: "")
            }
        }
        return out.map { it.value to it.key }
    }

    fun run(c: Context, name: String, a: JSONObject): String = try {
        when (name) {
            "find_contact" -> {
                val arr = a.getJSONArray("names")
                val qs = (0 until arr.length()).map { norm(arr.getString(it)) }.filter { it.length >= 2 }
                val hits = allContacts(c).filter { (n, _) -> val nn = norm(n); qs.any { nn.contains(it) } }.take(5)
                if (hits.isEmpty()) "مفيش جهة اتصال بالاسم ده" else hits.joinToString("\n") { "${it.first} | ${it.second}" }
            }
            "call_contact" -> Dial.call(c, a.getString("number"), a.optInt("sim", 1) - 1)
            "open_app" -> Apps.open(c, a.getString("label"))
            "set_alarm" -> {
                c.startActivity(
                    Intent(AlarmClock.ACTION_SET_ALARM)
                        .putExtra(AlarmClock.EXTRA_HOUR, a.getInt("hour"))
                        .putExtra(AlarmClock.EXTRA_MINUTES, a.getInt("minute"))
                        .putExtra(AlarmClock.EXTRA_MESSAGE, a.optString("label", ""))
                        .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
                "تم ضبط المنبه"
            }
            "save_note" -> {
                val d = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date())
                File(c.filesDir, "notes.txt").appendText("[$d] ${a.getString("text")}\n")
                "اتحفظت الملاحظة"
            }
            else -> "أداة مش معروفة"
        }
    } catch (e: Exception) {
        Log.e("CallBrief", "tool $name failed", e); "فشل: ${e.message}"
    }
}

/* ───────────── الـ Agent (Claude + بحث ويب + أدوات الجهاز) ───────────── */
object Agent {
    private val http = OkHttpClient.Builder().readTimeout(60, TimeUnit.SECONDS).build()
    private val hist = ArrayList<JSONObject>()
    private var lastAt = 0L
    @Volatile private var useSearch = true

    private fun s(d: String) = JSONObject().put("type", "string").put("description", d)
    private fun n(d: String) = JSONObject().put("type", "integer").put("description", d)
    private fun tool(name: String, desc: String, props: JSONObject, req: List<String>) =
        JSONObject().put("name", name).put("description", desc).put(
            "input_schema",
            JSONObject().put("type", "object").put("properties", props).put("required", JSONArray(req))
        )

    private fun tools(): JSONArray {
        val t = JSONArray()
        if (useSearch) t.put(JSONObject().put("type", "web_search_20250305").put("name", "web_search").put("max_uses", 3))
        t.put(tool("find_contact", "دور في جهات الاتصال. ابعت كل احتمالات الاسم بالعربي والإنجليزي.",
            JSONObject().put("names", JSONObject().put("type", "array").put("items", JSONObject().put("type", "string"))),
            listOf("names")))
        t.put(tool("call_contact", "اتصل برقم. sim=1 أو 2.",
            JSONObject().put("number", s("الرقم")).put("sim", n("رقم الشريحة 1 أو 2")), listOf("number")))
        t.put(tool("open_app", "افتح تطبيق باسمه زي ما هو في قايمة التطبيقات.",
            JSONObject().put("label", s("اسم التطبيق")), listOf("label")))
        t.put(tool("set_alarm", "اضبط منبه بالساعة 24 والدقيقة.",
            JSONObject().put("hour", n("الساعة 0-23")).put("minute", n("الدقيقة")).put("label", s("اسم المنبه")),
            listOf("hour", "minute")))
        t.put(tool("save_note", "احفظ ملاحظة نصية.", JSONObject().put("text", s("نص الملاحظة")), listOf("text")))
        return t
    }

    private fun system(c: Context): String {
        val now = SimpleDateFormat("EEEE yyyy-MM-dd HH:mm", Locale.US).format(Date())
        val city = Store.cfg(c, "city").ifBlank { "القاهرة" }
        return """أنت "حمودي"، مساعد صوتي شخصي بيتكلم مصري. ردودك بتتنطق بصوت عالي، فخليها قصيرة وطبيعية: جملة أو اتنين، من غير رموز ولا markdown ولا إيموجي. الوقت دلوقتي: $now. مدينة المستخدم: $city. الشريحة 1 = اورانج، الشريحة 2 = فودافون، والافتراضي 1. للطقس والأخبار والمعلومات الحديثة استخدم web_search وجاوب بدقة وبالأرقام. للاتصال: ابدأ بـ find_contact وابعت الاسم بالعربي والإنجليزي، ولو لقيت أكتر من واحد اسأل المستخدم مين، وبعدين call_contact. لفتح تطبيق اختار اسمه بالظبط من القايمة دي: ${Apps.labels(c).joinToString(", ")}. بعد تنفيذ أي أمر قول بجملة قصيرة إنك عملته."""
    }

    private fun post(c: Context, body: JSONObject): JSONObject {
        val req = Request.Builder().url("https://api.anthropic.com/v1/messages")
            .header("x-api-key", Store.cfg(c, "key")).header("anthropic-version", "2023-06-01")
            .post(body.toString().toRequestBody("application/json".toMediaType())).build()
        http.newCall(req).execute().use { r ->
            val raw = r.body?.string() ?: ""
            if (!r.isSuccessful) {
                if (r.code == 400 && raw.contains("web_search")) throw IllegalStateException("search off")
                throw RuntimeException("HTTP ${r.code}: $raw")
            }
            return JSONObject(raw)
        }
    }

    fun ask(c: Context, text: String): String {
        if (System.currentTimeMillis() - lastAt > 120_000) hist.clear()
        val msgs = JSONArray()
        hist.forEach { msgs.put(it) }
        msgs.put(JSONObject().put("role", "user").put("content", text))
        var finalText = ""
        for (k in 0 until 6) {
            val body = JSONObject().put("model", "claude-haiku-5-5").put("max_tokens", 700)
                .put("system", system(c)).put("tools", tools()).put("messages", msgs)
            val resp = try { post(c, body) } catch (e: IllegalStateException) { useSearch = false; continue }
            val content = resp.getJSONArray("content")
            msgs.put(JSONObject().put("role", "assistant").put("content", content))
            val stop = resp.optString("stop_reason")
            if (stop == "tool_use") {
                val results = JSONArray()
                for (i in 0 until content.length()) {
                    val b = content.getJSONObject(i)
                    if (b.getString("type") == "tool_use") results.put(
                        JSONObject().put("type", "tool_result").put("tool_use_id", b.getString("id"))
                            .put("content", Tools.run(c, b.getString("name"), b.getJSONObject("input")))
                    )
                }
                msgs.put(JSONObject().put("role", "user").put("content", results))
            } else if (stop != "pause_turn") {
                finalText = (0 until content.length()).map { content.getJSONObject(it) }
                    .filter { it.getString("type") == "text" }.joinToString(" ") { it.getString("text") }
                break
            }
        }
        finalText = finalText.replace(Regex("[*#_`]"), "").trim().ifBlank { "تمام" }
        hist.add(JSONObject().put("role", "user").put("content", text))
        hist.add(JSONObject().put("role", "assistant").put("content", finalText))
        while (hist.size > 8) { hist.removeAt(0); hist.removeAt(0) }
        lastAt = System.currentTimeMillis()
        return finalText
    }
}

/* ───────────── خدمة "حمودي" (وضع الاستعداد) ───────────── */
class HamoudiService : Service(), TextToSpeech.OnInitListener {
    private val h = Handler(Looper.getMainLooper())
    private var sr: SpeechRecognizer? = null
    private lateinit var tts: TextToSpeech
    private var ttsReady = false
    private var speaking = false
    @Volatile private var working = false
    private var cmdNext = false
    private var afterSpeak: (() -> Unit)? = null
    private val loop = Runnable { listenNow() }
    private val wake = Regex("حمودي|حمودى|هامودي|hamoudi|hamoodi|hamody|hamodi", RegexOption.IGNORE_CASE)

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel("hamoudi", "حمودي", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "hamoudi").setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("حمودي شغال").setContentText("قول: حمودي").build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(2, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        else startForeground(2, n)
        tts = TextToSpeech(this, this)
    }

    override fun onStartCommand(i: Intent?, f: Int, id: Int) = START_STICKY

    override fun onInit(s: Int) {
        ttsReady = s == TextToSpeech.SUCCESS
        if (ttsReady) {
            tts.language = Locale("ar", "EG")
            tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(id: String?) {}
                override fun onDone(id: String?) { h.post { finishSpeak() } }
                @Deprecated("deprecated") override fun onError(id: String?) { h.post { finishSpeak() } }
            })
        }
        listen(false)
    }

    private fun finishSpeak() {
        speaking = false
        val a = afterSpeak; afterSpeak = null
        if (a != null) a() else listen(false)
    }

    private fun speak(t: String, after: () -> Unit) {
        sr?.destroy(); sr = null
        if (!ttsReady) { after(); return }
        speaking = true; afterSpeak = after
        if (tts.speak(t, TextToSpeech.QUEUE_FLUSH, null, "u") == TextToSpeech.ERROR) { speaking = false; after() }
    }

    private fun listen(command: Boolean, delay: Long = 0) {
        cmdNext = command
        h.removeCallbacks(loop); h.postDelayed(loop, delay)
    }

    private fun listenNow() {
        val command = cmdNext
        if (speaking || working) return
        if (Assistant.paused()) { listen(command, 1500); return }
        sr?.destroy()
        sr = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onResults(r: Bundle?) =
                    onText(r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: "", command)
                override fun onError(e: Int) {
                    if (e == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) { stopSelf(); return }
                    val busy = e == SpeechRecognizer.ERROR_RECOGNIZER_BUSY || e == 10
                    listen(false, if (busy) 2000 else 300)
                }
                override fun onReadyForSpeech(p: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(v: Float) {}
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(r: Bundle?) {}
                override fun onEvent(t: Int, p: Bundle?) {}
            })
            startListening(
                Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                    .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ar-EG")
                    .putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
            )
        }
    }

    private fun onText(t: String, command: Boolean) {
        if (command) { if (t.isBlank()) listen(false) else handle(t); return }
        val m = wake.find(t)
        if (m == null) { listen(false); return }
        val rest = t.substring(m.range.last + 1).trim { it in " ،,.:!؟?" }
        if (rest.length >= 3) handle(rest) else speak("أيوه، سامعك") { listen(true) }
    }

    private fun handle(t: String) {
        sr?.destroy(); sr = null
        working = true
        Thread {
            val reply = try { Agent.ask(this, t) } catch (e: Exception) {
                Log.e("CallBrief", "agent failed", e); "حصلت مشكلة، جرّب تاني"
            }
            h.post {
                working = false
                val q = reply.trimEnd().let { it.endsWith("؟") || it.endsWith("?") }
                speak(reply) { listen(q) }
            }
        }.start()
    }

    override fun onDestroy() {
        h.removeCallbacksAndMessages(null)
        sr?.destroy()
        if (ttsReady) tts.shutdown()
        super.onDestroy()
    }
}
